name  = "luaecs"
words = { "ecs%.world()" }
