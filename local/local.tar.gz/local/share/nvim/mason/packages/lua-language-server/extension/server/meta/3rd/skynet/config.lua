name  = "skynet"
words = { "skynet.start" }
