words = { "require[%s%(\"\']+luassert[%)\"\']" }
